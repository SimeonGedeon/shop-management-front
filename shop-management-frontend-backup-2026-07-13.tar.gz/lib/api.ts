// lib/api.ts

import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';

console.log('API URL:', API_URL);

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
});

// Intercepteur pour ajouter le token
api.interceptors.request.use((config) => {
  // Vérifier si on est côté client
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

// Intercepteur pour gérer les erreurs 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// ==========================================
// SERVICES API
// ==========================================

// Service d'authentification
export const authService = {
  login: (data: { login: string; password: string }) =>
    api.post('/auth/login', data),
  logout: () => api.post('/auth/logout'),
  me: () => api.get('/auth/me'),
  register: (data: any) => api.post('/auth/register', data),
  changePassword: (data: { current_password: string; new_password: string }) =>
    api.post('/auth/change-password', data),
};

// Service Dashboard
export const dashboardService = {
  get: () => api.get('/dashboard'),
};

// Service Stocks
export const stockService = {
  getAll: (date?: string) => api.get('/stocks', { params: { date } }),
  getAlertes: () => api.get('/stocks/alertes'),
  getHistorique: (params?: any) => api.get('/stocks/historique', { params }),
  getRapport: () => api.get('/stocks/rapport'),
  setMatin: (stocks: { reseau_id: number; stock_matin: number }[]) =>
    api.post('/stocks/matin', { stocks }),
  setSoir: (stocks: { reseau_id: number; stock_soir: number; achats_jour?: number }[]) =>
    api.post('/stocks/soir', { stocks }),
  vendre: (data: { reseau_id: number; montant_encaisse: number }) =>
    api.post('/stocks/vendre', data),
  reapprovisionner: (data: { reseau_id: number; quantite: number; prix_achat: number }) =>
    api.post('/stocks/reapprovisionner', data),
};

// Service Mobile Money
export const mmService = {
  getSoldes: () => api.get('/mm/soldes'),
  getTransactions: (params?: any) => api.get('/mm/transactions', { params }),
  createTransaction: (data: {
    type: 'depot' | 'retrait';
    montant: number;
    operateur: string;
    description?: string;
  }) => api.post('/mm/transactions', data),
  updateTransaction: (id: number, data: any) =>
    api.put(`/mm/transactions/${id}`, data),
  deleteTransaction: (id: number) =>
    api.delete(`/mm/transactions/${id}`),
};

// Service Archives
export const archiveService = {
  getAll: () => api.get('/archives'),
  getSemaine: () => api.get('/archives/semaine'),
  getByDate: (date: string) => api.get(`/archives/${date}`),
  exportByDate: (date: string) =>
    api.get(`/archives/${date}/export`, { responseType: 'blob' }),
};

// Service Articles
export const articleService = {
  getAll: (date?: string) => api.get('/articles', { params: { date } }),
  create: (data: { designation: string; prix_achat: number; prix_unitaire: number; nombre_pieces: number }) =>
    api.post('/articles', data),
  updateSoir: (id: number, restant_soir: number) =>
    api.put(`/articles/${id}`, { restant_soir }),
  delete: (id: number) => api.delete(`/articles/${id}`),
};

// Service Paramètres
export const settingsService = {
  get: () => api.get('/settings'),
  update: (data: any) => api.put('/settings', data),
  reset: () => api.post('/settings/reset'),
};

// Service Réseaux
export const reseauService = {
  getAll: () => api.get('/reseaux'),
  getById: (id: number) => api.get(`/reseaux/${id}`),
  create: (data: any) => api.post('/reseaux', data),
  update: (id: number, data: any) => api.put(`/reseaux/${id}`, data),
  delete: (id: number) => api.delete(`/reseaux/${id}`),
  calculerUnites: (id: number, data: { montant: number }) =>
    api.post(`/reseaux/${id}/calculer-unites`, data),
};

// Service Objectifs
export const objectifService = {
  get: () => api.get('/objectif'),
  update: (data: any) => api.put('/objectif', data),
};

export const caisseService = {
  getResume: () => api.get('/caisse/resume'),
  getEtat: () => api.get('/caisse/etat'),
  getHistorique: (params?: any) => api.get('/caisse/historique', { params }),
  setSoir: (data: any) => api.post('/caisse/soir', data),
  cloturer: () => api.post('/caisse/cloturer'),
  addDepense: (data: { motif: string; montant: number }) => api.post('/caisse/depenses', data),
  deleteDepense: (id: number) => api.delete(`/caisse/depenses/${id}`),
};

// Service Utilisateurs (Admin)
export const userService = {
  getAll: () => api.get('/users'),
  create: (data: any) => api.post('/users', data),
  update: (id: number, data: any) => api.put(`/users/${id}`, data),
  delete: (id: number) => api.delete(`/users/${id}`),
};

export const detteService = {
  getResume: () => api.get('/dettes/resume'),
  getAll: (params?: any) => api.get('/dettes', { params }),
  create: (data: any) => api.post('/dettes', data),
  update: (id: number, data: any) => api.put(`/dettes/${id}`, data),
  rembourser: (id: number, montant: number) => api.post(`/dettes/${id}/rembourser`, { montant }),
  annuler: (id: number) => api.delete(`/dettes/${id}`),
};

// Export par défaut pour les cas où on veut utiliser l'instance directement
export default api;